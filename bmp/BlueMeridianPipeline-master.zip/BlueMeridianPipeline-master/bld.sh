#!/bin/bash

# build all output

rm -Rf output/*

tiddlywiki wiki --verbose --output ./output --excel-import "input/raw-excel-doc/Raw Pipeline.xlsx" "$:/_ExcelImportSpec/Workbook/Pipeline" --build index encrypted

##########################################################################################
# Old, Word-based implementation follows
##########################################################################################

# rm -Rf output/*

# ./node_modules/mammoth/bin/mammoth input/raw-word-doc/Raw\ Pipeline.docx output/pipeline-body.html --style-map=input/custom-style-map

# cat input/html-parts/prefix.html output/pipeline-body.html input/html-parts/suffix.html > output/pipeline.html

# rm output/pipeline-body.html

# tiddlywiki wiki --verbose --output ./output --fillet "$:/_RawPipeline" --build index encrypted

# rm output/pipeline.html
