#!/bin/bash

# build all output

cp output/* ~/Dropbox/Blue\ Meridian\ Partners/Shared\ Prototype/
