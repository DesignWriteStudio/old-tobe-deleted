# Blue Meridian Partners Pipeline

## Building

1. Install Node.js from https://nodejs.org/
2. Install TiddlyWiki, as described [here](http://tiddlywiki.com/#Installing%20TiddlyWiki%20Prerelease%20on%20Node.js)
3. Download or clone this repo
4. Open a command window, and switch to the root directory of this repo
5. Type `npm install` and press return
6. Run the commands in `bld.sh`
7. The built `index.html` will be in the `output` subfolder of your copy of the repo
