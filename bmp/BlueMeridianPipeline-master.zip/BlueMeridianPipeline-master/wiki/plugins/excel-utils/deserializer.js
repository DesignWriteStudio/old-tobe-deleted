/*\
title: $:/plugins/tiddlywiki/excel-utils/deserializer.js
type: application/javascript
module-type: tiddlerdeserializer

XLSX file deserializer

\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

/*
Parse an XLSX file into tiddlers
*/
exports["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"] = function(text,fields) {
	// Collect output tiddlers in an array
	var results = [],
		ExcelImporter = require("$:/plugins/tiddlywiki/excel-utils/importer.js").ExcelImporter,
		importer = new ExcelImporter({
			text: text
		});
	// Return the output tiddlers
	return importer.importTiddlers();
};

})();
