/*\
title: $:/plugins/tiddlywiki/excel-utils/excel-import-command.js
type: application/javascript
module-type: command

Command to import an Excel file

\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

exports.info = {
	name: "excel-import",
	synchronous: true
};

var Command = function(params,commander,callback) {
	this.params = params;
	this.commander = commander;
	this.callback = callback;
};

Command.prototype.execute = function() {
	if(this.params.length < 1) {
		return "Missing parameters";
	}
	var self = this,
		wiki = this.commander.wiki,
		filename = this.params[0],
		importSpec = this.params[1],
		ExcelImporter = require("$:/plugins/tiddlywiki/excel-utils/importer.js").ExcelImporter,
		importer = new ExcelImporter({
			filename: filename,
			importSpec: importSpec
		});
	$tw.wiki.addTiddlers(importer.importTiddlers());
	return null;
};

exports.Command = Command;

})();
