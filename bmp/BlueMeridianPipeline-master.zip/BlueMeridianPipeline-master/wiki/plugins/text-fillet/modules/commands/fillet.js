/*\
title: $:/plugins/tiddlywiki/text-fillet/modules/commands/fillet.js
type: application/javascript
module-type: command

Command to fillet a specified tiddler

\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

var widget = require("$:/core/modules/widgets/widget.js");

exports.info = {
	name: "fillet",
	synchronous: false
};

var Command = function(params,commander,callback) {
	this.params = params;
	this.commander = commander;
	this.callback = callback;
};

Command.prototype.execute = function() {
	if(this.params.length < 1) {
		return "Missing parameters";
	}
	var self = this,
		wiki = this.commander.wiki,
		sourceTitle = this.params[0],
		filleter = new $tw.Filleter(wiki,sourceTitle);
	filleter.filletTiddler();
	$tw.utils.nextTick(this.callback);
	return null;
};

exports.Command = Command;

})();
