/*\
title: $:/plugins/tiddlywiki/text-fillet/modules/filleter.js
type: application/javascript
module-type: global

Main text-filleting logic

\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

var DOMParser = require("$:/plugins/tiddlywiki/xmldom/dom-parser").DOMParser;

function Filleter(wiki,sourceTitle,options) {
	options = options || {};
	this.wiki = wiki;
	this.sourceTitle = sourceTitle;
}

Filleter.prototype.filletTiddler = function() {
	// Check the source tiddler
	var sourceTiddler = this.wiki.getTiddler(this.sourceTitle);
	if(!sourceTiddler || !sourceTiddler.fields.text) {
		throw "Source tiddler not found";
	}
	if(sourceTiddler.fields.type !== "text/html") {
		throw "Source tiddler must be of type text/html";
	}
	// Parse the source tiddler
	this.sourceDoc = this.parseSource(sourceTiddler.fields.text);
	// Get the main headings
	var headings = this.sourceDoc.getElementsByTagName("h1");
	// Extract the introduction section
	this.getBodyText({
		headingDomNode: headings[0],
		requiredText: "Introduction",
		targetTiddler: {
			title: "Introduction",
			role: "introduction",
			tags: "$:/tags/ToolbarItem"
		}
	});
	// Extract the organizations
	this.getTaggedSegmentedHeadings({
		headingDomNode: headings[1],
		level: 1,
		handleMore: true,
		requiredText: "Organizations",
		subheadings: ["domain","sub-domain"],
		segments: [
			{heading: "Issue Area", bodyType: "tags"},
			{heading: "Logo", bodyType: "image"},
			{heading: "Description", bodyType: "text"},
			{heading: "Summary Assessment", bodyType: "text"},
			{heading: "Current View", bodyType: "text"}
		],
		subheadingTiddler: {
			role: "subheading"
		},
		subjectTiddler: {
			role: "organization"
		},
		segmentTiddler: {
			role: "organization-info"
		}
	});
};

Filleter.prototype.parseSource = function(text) {
	return new DOMParser().parseFromString(text,"text/html");
};

/*
Retrieve the subheadings immediately under a heading. Make each subheading into a separate tiddler with the body text in the text field, and the title taken from the subheading

The options parameter supports the following properties:

headingDomNode: DOM node of the heading
level: expected numerical heading level
requiredText: Optional text that must match the heading text (error thrown if no match)
subheadings: Array of tag names for intervening subheadings
segments: Array of segment descriptors (see below)
subheadingTiddler: Fields to be assigned to the created subheading tiddlers
subjectTiddler: Fields to be assigned to the created subject tiddlers
segmentTiddler: Fields to be assigned to the created subject segment tiddlers
handleMore: True to handle "(more)" marker by wrapping subsequent text with a conditional

Segment descriptors have the following fields:

heading: Text of heading marking segment
type: One of the following strings
	"tags": each paragraph of body text is taken as a tag to be assigned to the tiddler
	"image": one image is extracted from the body text and turned into an image tiddler
	"text": all the body text is assigned to the text field

Returns the DOM node of the heading that terminated the body text
*/
Filleter.prototype.getTaggedSegmentedHeadings = function(options) {
	// Check the text of the heading
	this.checkHeading(options);
	// Walk through the intervening subheadings
	var domNode = options.headingDomNode.nextSibling,
		subheadings = [];
	while(domNode) {
		// Determine the status of the next heading from its level
		var tagName = domNode.tagName.toLowerCase(),
			headingLevel = parseInt(tagName.substr(1),10),
			targetTiddler;
		// Back to the starting level means we're done
		if(tagName === "h" + options.level) {
			break;
		}
		// Check for another heading
		if(this.isHeading(tagName)) {
			if(headingLevel >= options.level && headingLevel <= options.level + options.subheadings.length) {
				// Intervening subheading
				// Save the heading text
				subheadings[headingLevel - options.level - 1] = domNode.textContent;
				// Create the tiddler
				targetTiddler = $tw.utils.extend({},options.subheadingTiddler,{
					title: domNode.textContent,
					role: options.subheadings[headingLevel - options.level - 1],
					parent: headingLevel > options.level + 1 ? subheadings[headingLevel - options.level - 2] : ""
				});
				domNode = this.getBodyText({
					headingDomNode: domNode,
					requiredText: null,
					targetTiddler: targetTiddler,
					handleMore: options.handleMore
				});
			} else if(headingLevel === options.level + options.subheadings.length + 1) {
				// Subject heading
				var subjectTitle = domNode.textContent;
				// Process the segment headings
				domNode = domNode.nextSibling;
				var segmentHeadingTagName = "h" + (options.level + options.subheadings.length + 2),
					segments = [],
					currSegment = 0;
				while(domNode && domNode.tagName.toLowerCase() === segmentHeadingTagName) {
					var segmentTitle = subjectTitle + " (" + domNode.textContent + ")";
					segments.push(segmentTitle);
					targetTiddler = $tw.utils.extend({},options.segmentTiddler,{
						title: segmentTitle,
						parent: subjectTitle,
						caption: domNode.textContent
					});
					domNode = this.getBodyText({
						headingDomNode: domNode,
						requiredText: options.segments[currSegment].heading,
						bodyType: options.segments[currSegment].bodyType,
						targetTiddler: targetTiddler,
						handleMore: options.handleMore
					});
					currSegment = currSegment+1;
				}
				// Create the subject tiddler
				this.addTiddler(options.subjectTiddler,{
					title: subjectTitle,
					tags: subheadings.slice(0),
					list: segments
				});
			} else {
				// Something went wrong
				throw "Unexpected element: " + domNode.textContent;
			}
		} else {
			// Something went wrong
			throw "Unexpected element: " + domNode.textContent;
		}
	};
	return domNode;
};

/*
Retrieve the body text immediately following a heading up until the next heading and store it in a new tiddler.

The options parameter supports the following properties:

headingDomNode: DOM node of the heading
requiredText: Optional text that must match the heading text (error thrown if no match)
bodyType: Type of body text to be retrieved: "text", "tags", "image"
targetTiddler: Fields to be assigned to the created tiddler
handleMore: True to handle "(more)" marker by wrapping subsequent text with a conditional

Returns the DOM node of the heading that terminated the body text
*/
Filleter.prototype.getBodyText = function(options) {
	var domNode,imageNode,result,hadMoreMarker;
	// Check the text of the heading
	this.checkHeading(options);
	// Handle the required body type
	switch(options.bodyType || "text") {
		case "tags":
		case "text":
			// Accumulate the sibling nodes until the next heading
			result = [];
			domNode = options.headingDomNode.nextSibling;
			while(domNode && !this.isHeading(domNode.tagName)) {
				if(options.handleMore && domNode.textContent === "(more)") {
					result.push("<<tv-hide-more-controls>><$list filter='[<tv-hide-more>!prefix[yes]]'>");
					hadMoreMarker = true;
				} else {
					result.push(domNode.toString());
				}
				domNode = domNode.nextSibling;
			}
			if(hadMoreMarker) {
				result.push("</$list>");
			}
			// Store the result in a tiddler
			this.addTiddler(options.targetTiddler,{
				text: result.join("")
			});
			break;
		case "image":
			// Iterate through sibling and child notes until we find an image
			var searchForImage = function(domNode) {
				while(domNode) {
					if(domNode.tagName && domNode.tagName.toLowerCase() === "img" && !imageNode) {
						imageNode = domNode;
					}
					if(domNode.hasChildNodes) {
						searchForImage(domNode.firstChild);
					}
					domNode = domNode.nextSibling;
				}
			};
			domNode = options.headingDomNode.nextSibling;
			imageNode = null;
			while(domNode && !this.isHeading(domNode.tagName)) {
				if(domNode.hasChildNodes) {
					searchForImage(domNode.firstChild);
				}
				domNode = domNode.nextSibling;
			}
			if(!imageNode) {
				throw "Missing image under heading '" + options.headingDomNode.textContent + "'";
			}
			// Store the result in a tiddler
			var src = imageNode.getAttribute("src").split(";base64,");
			this.addTiddler(options.targetTiddler,{
				type: src[0].substr(5),
				text: src[1]
			});
			break;
	}
	return domNode;
};

/*
Add a tiddler to the store, setting the creation and modification details
*/
Filleter.prototype.addTiddler = function(/* args */) {
	var args = [null,this.wiki.getCreationFields()].concat(Array.prototype.slice.call(arguments,0),this.wiki.getModificationFields());
    var factoryFunction = $tw.Tiddler.bind.apply($tw.Tiddler,args),
    	tiddler = new factoryFunction();
//console.log("Adding ",tiddler.fields.title,tiddler.fields)
    this.wiki.addTiddler(tiddler);
};

/*
Check that the content of a heading matches specified text, and throw an error if it does not

The options parameter supports the following properties:

headingDomNode: DOM node of the heading
requiredText: Optional text that must match the heading text (error thrown if no match)
*/
Filleter.prototype.checkHeading = function(options) {
	if(options.requiredText && options.headingDomNode.textContent !== options.requiredText) {
		throw "Missing heading '" + options.requiredText + "'";
	}
};

/*
Return true if a tag name corresponds to a heading
*/
Filleter.prototype.isHeading = function(tagName) {
	return /^h[1-6]$/i.test(tagName);
};

exports.Filleter = Filleter;

})();
