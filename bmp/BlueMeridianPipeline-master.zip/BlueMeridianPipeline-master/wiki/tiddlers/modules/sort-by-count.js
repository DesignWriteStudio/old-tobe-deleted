/*\
title: $:/core/modules/filters/sort-by-count.js
type: application/javascript
module-type: filteroperator

Filter operator for sorting by the count of a sub-filter (passed as the operand).

The sub-filter is invoked with currentTiddler set to each input tiddler and then we sort the original titles by the count of sub-filter results.

\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

/*
Export our filter function
*/
exports["sort-by-count"] = function(source,operator,options) {
	// Get the source titles
	var sourceTitles = [];
	source(function(tiddler,title) {
		sourceTitles.push(title);
	});
	// Count the number of results for each input value
	var subFilterFn = options.wiki.compileFilter(operator.operand),
		resultCounts = Object.create(null);
	sourceTitles.forEach(function(title) {
		if(!$tw.utils.hop(resultCounts,title)) {
			// We make a fake widget so that the filter function can call widget.getVariable()
			var widget ={
					getVariable: function(name,options) {
						if(name === "currentTiddler") {
							return title;
						}
						return options.widget.getVariable(name,options);
					}
				};
			resultCounts[title] = subFilterFn(null,widget).length;
		}
	});
	// Sort the titles by the result count
	var sortFunction;
	if(operator.prefix === "!") {
		sortFunction = function(a,b) {
			return (resultCounts[b] || 0) - (resultCounts[a] || 0);
		};
	} else {
		sortFunction = function(a,b) {
			return (resultCounts[a] || 0) - (resultCounts[b] || 0);
		};
	}
	sourceTitles.sort(sortFunction);
	return sourceTitles;
};

})();
